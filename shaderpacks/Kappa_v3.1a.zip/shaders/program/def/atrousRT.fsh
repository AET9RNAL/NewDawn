/*
====================================================================================================

    Copyright (C) 2020 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

#include "/lib/head.glsl"

/*DRAWBUFFERS:3*/
layout(location = 0) out vec4 lightmapData;

in vec2 coord;

uniform sampler2D colortex3;
uniform sampler2D colortex6;

uniform sampler2D depthtex0;

uniform float far, near;

uniform vec2 viewSize, taaOffset;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelView;

#ifndef ATROUS_SIZE
    #define ATROUS_SIZE 1
#endif


vec3 screenToViewSpace(vec3 screenpos, mat4 projInv, const bool taaAware) {
    screenpos   = screenpos*2.0-1.0;

    #ifdef taaEnabled
        if (taaAware) screenpos.xy -= taaOffset;
    #endif

    vec3 viewpos    = vec3(vec2(projInv[0].x, projInv[1].y)*screenpos.xy + projInv[3].xy, projInv[3].z);
        viewpos    /= projInv[2].w*screenpos.z + projInv[3].w;
    
    return viewpos;
}

vec3 screenToViewSpace(vec3 screenpos, mat4 projInv) {    
    return screenToViewSpace(screenpos, projInv, true);
}

vec3 screenToViewSpace(vec3 screenpos) {
    return screenToViewSpace(screenpos, gbufferProjectionInverse);
}

/* ------ includes ------*/
#define FUTIL_LINDEPTH
#include "/lib/fUtil.glsl"

#include "/lib/util/kernel.glsl"

#include "/lib/light/indirect/atrous.glsl"

void main() {
    vec4 data   = atrous3x3(colortex3, depthtex0, colortex6, coord, ATROUS_SIZE);
    
    lightmapData = clampDrawbuffer(data);
}