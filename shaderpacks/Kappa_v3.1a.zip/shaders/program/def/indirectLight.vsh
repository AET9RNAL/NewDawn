/*
====================================================================================================

    Copyright (C) 2020 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

#include "/lib/head.glsl"
#include "/lib/util/colorspace.glsl"

out vec2 coord;

flat out vec3 blocklightColor;

#if (!defined DIM || DIM == 1)
    flat out vec3 directLightColor;
#endif

#if (!defined DIM || !defined rtaoSkySample || !defined rtaoEnabled)
    flat out vec3 indirectLightCol;
#endif

#ifndef DIM
    uniform float eyeAltitude;
    uniform float lightFlip;
    uniform float sunAngle;
    uniform float wetness;

    uniform vec3 sunvec;
    uniform vec3 moonvec;

    uniform vec4 daytime;

    #include "/lib/atmos/air/const.glsl"
    #include "/lib/atmos/air/density.glsl"

    #if (!defined rtaoSkySample || !defined rtaoEnabled)
        uniform vec2 viewSize;

        uniform sampler2D gaux2;

        #include "/lib/atmos/project.glsl"
    #endif
#endif

#if DIM == -1
    uniform vec3 fogColor;
#endif

void main() {
    gl_Position = vec4(gl_Vertex.xy * 2.0 - 1.0, 0.0, 1.0);
    coord = gl_MultiTexCoord0.xy;

    #ifndef DIM
        vec3 sunColor = getAirTransmittance(vec3(0.0, planetRad + eyeAltitude, 0.0), sunvec, 6) * sunIllum;

        directLightColor = (sunAngle<0.5 ? sunColor * sunlightIllum * (1.0 - wetness * 0.8) : getAirTransmittance(vec3(0.0, planetRad + eyeAltitude, 0.0), moonvec) * moonIllum) * lightFlip;
    #elif DIM == 1
        directLightColor = endSunlightColor * 0.2 / pi;
    #endif

    blocklightColor  = blackbody(float(blocklightBaseTemp)) * tau;

    #if (!defined DIM && (!defined rtaoSkySample || !defined rtaoEnabled))
        indirectLightCol    = texture(gaux2, projectSky(vec3(0.0, 1.0, 0.0))).rgb * pi * skylightIllum;
        indirectLightCol    = mix(indirectLightCol, vec3(v3avg(indirectLightCol) * 0.72), wetness * 0.95);
        indirectLightCol   *= vec3(skylightRedMult, skylightGreenMult, skylightBlueMult);
    #elif DIM == -1
        indirectLightCol    = mix(netherSkylightColor, linearToAP1(normalize(toLinear(fogColor))), 0.85) * 0.3;
    #elif DIM == 1
        indirectLightCol    = endSkylightColor * 0.3;
    #endif
}