/*
====================================================================================================

    Copyright (C) 2020 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

#ifdef cloudPass
    const float eyeAltitude = 800.0;
#else
    uniform float eyeAltitude;
#endif

uniform float wetness;

uniform vec2 viewSize;

uniform vec3 sunvec;
uniform vec3 moonvec;

uniform vec4 daytime;

uniform sampler2D gaux2;

#ifdef skyboxPass
    flat out vec3 airIlluminance;
    flat out mat2x3 airIllumMod;
#else
    flat out mat4x3 lightColor;
#endif

#ifdef skyboxPass
    #include "/lib/atmos/phase.glsl"
    #include "/lib/atmos/air/atmosphere.glsl"
#else
    #define airmassStepBias 0.33
    #include "/lib/atmos/air/const.glsl"
    #include "/lib/atmos/air/density.glsl"
    #include "/lib/atmos/project.glsl"
#endif

void make_colors() {
    #ifdef skyboxPass
        airIlluminance  = atmosphericScattering(vec3(0.0, 1.0, 0.0), mat2x3(sunvec, moonvec), vec3(0.0), mat2x3(0.0));
        //airIlluminance = mix(airIlluminance, vec3(airIlluminance.z), 0.33) * rcp(pi);

        vec3 airEyePos = vec3(0.0, planetRad + eyeAltitude, 0.0);
        airIllumMod     = mat2x3(getAirTransmittance(airEyePos, sunvec, 6)  * sunIllum  / sunIllum.r, 
                                 getAirTransmittance(airEyePos, moonvec, 6) * moonIllum / moonIllum.b);
    #else
        vec3 airEyePos = vec3(0.0, planetRad + eyeAltitude, 0.0);

        lightColor[0]  = getAirTransmittance(airEyePos, sunvec, 6) * sunIllum * sunlightIllum;

        #if !(defined cloudPass || defined skyboxPass || defined cloudShadowsEnabled)
        lightColor[0] *= (1.0 - wetness * 0.95);
        #endif
        
        #ifdef fogPass
            lightColor[1]  = texture(gaux2, projectSky(vec3(0.0, 1.0, 0.0))).rgb * skylightIllum;
        #elif (defined cloudPass)
            lightColor[1]  = texture(gaux2, projectSky(vec3(0.0, 1.0, 0.0))).rgb * pi * 0.25;
        #else
            lightColor[1]  = texture(gaux2, projectSky(vec3(0.0, 1.0, 0.0))).rgb * pi * skylightIllum;
            lightColor[1]  = mix(lightColor[1], vec3(v3avg(lightColor[1]) * 0.72), wetness * 0.95);
        #endif

        lightColor[1] *= vec3(skylightRedMult, skylightGreenMult, skylightBlueMult);

        lightColor[2]  = getAirTransmittance(airEyePos, moonvec, 6) * moonIllum * moonlightIllum;
        
    #ifndef skipBlocklight
        lightColor[3]  = blackbody(float(blocklightBaseTemp)) * blocklightIllum * tau;
    #endif

        //lightColor[3]  = vec3(0.4, 0.7, 1.0)*0.05;
    #endif
}