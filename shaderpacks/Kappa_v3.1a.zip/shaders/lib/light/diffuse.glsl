/*
====================================================================================================

    Copyright (C) 2020 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

#define diffuseModel 0   //[0 1]

float diffuseLambert(vec3 normal, vec3 lightDir) {
    float lamb  = dot(normal, lightDir);
        lamb    = saturate(lamb);
    return lamb * rpi;
}

/*
float diffuseOrenNayar(vec3 normal, vec3 viewDir, vec3 lightDir, float roughness) {    //reeee, no gud
    vec3 h  = normalize(viewDir + lightDir);

    float nDotL     = saturate(dot(normal, lightDir));

    float nDotV     = saturate(dot(normal, viewDir));

    float t     = max(nDotL, nDotV);
    float g     = max(dot(viewDir-normal*nDotV, lightDir-normal*nDotL), 0.0);
    float c     = g*rcp(t) - g*t;
    float a     = 0.285 * rcp(roughness + 0.57) + 0.5;
    float b     = 0.45 * roughness * rcp(roughness + 0.09);

    return max(max(nDotL, 0.0) * (b * c + a), 0.0);
}*/