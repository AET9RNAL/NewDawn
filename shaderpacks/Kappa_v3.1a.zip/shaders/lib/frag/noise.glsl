/*
====================================================================================================

    Copyright (C) 2020 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

vec3 noise2D(vec2 pos) {
    return texture(noisetex, pos).xyz;
}

float value3D(vec3 pos) {
    vec3 p  = floor(pos); 
    vec3 b  = fract(pos);

    vec2 uv = (p.xy+vec2(-97.0)*p.z)+b.xy;
    vec2 rg = texture(noisetex, (uv)/256.0).xy;

    return cubeSmooth(mix(rg.x, rg.y, b.z));
}

/*
vec2 textureCubicRG(sampler2D tex, vec2 pos) {
    vec4 samplesR    = textureGather(tex, pos, 0);
    vec4 samplesG    = textureGather(tex, pos, 1);

    vec2 weights    = fract(pos * 256.0 - 0.5);
        //weights     = linStep(weights, 0.01, 1.0);
        //weights     = cubeSmooth(saturate(weights));

    float R = mix(
        mix(samplesR.w, samplesR.z, weights.x),
        mix(samplesR.x, samplesR.y, weights.x), weights.y
        );

    float G = mix(
        mix(samplesG.w, samplesG.z, weights.x),
        mix(samplesG.x, samplesG.y, weights.x), weights.y
        );

    return vec2(R, G);
}
float value3DSmooth(vec3 pos) {
    vec3 p  = floor(pos); 
    vec3 b  = fract(pos);

    vec2 uv = (p.xy+vec2(-97.0)*p.z)+b.xy;
    vec2 rg = textureCubicRG(noisetex, (uv)/256.0);

    return cubeSmooth(mix(rg.x, rg.y, b.z));
}*/