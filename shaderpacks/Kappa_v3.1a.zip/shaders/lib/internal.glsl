/*
====================================================================================================

    Copyright (C) 2020 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

#ifndef DIM
    #define rtaoSkySample
#elif DIM == -1
    #define NOSHADOWMAP
#endif


#define SKY_RENDER_LOD 3

#define DEBUG_VIEW 0    //[0 1 2 3 4 5 6] 0-off, 1-whiteworld, 2-indirect Occlusion, 3-indirect light, 4-albedo, 5-hdr, 6-reflections
//#define DEBUG_WITH_ALBEDO
//#define RTAO_NOSKYMAP

//#define deffNAN
//#define compNAN

const float indirectResScale = sqrt(1.0 / indirectResReduction);


#define sunlightIllum 1.0   //[0.1 0.2 0.3 0.4 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0]
#define moonlightIllum 1.0  //[0.1 0.2 0.3 0.4 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0]
#define skylightIllum 1.0   //[0.1 0.2 0.3 0.4 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0]
#define blocklightIllum 1.0 //[0.1 0.2 0.3 0.4 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0]
#define blocklightBaseTemp 3400     //[1000 1200 1400 1600 1800 2000 2200 2400 2600 2800 3000 3200 3400 3600 3800 4000 4200 4400 4600 4800 5000]

#define netherSkylightColor vec3(1.0, 0.23, 0.08)
#define endSkylightColor vec3(0.4, 0.2, 1.0)
#define endSunlightColor vec3(0.5, 0.3, 1.0)

#define cloudShadowmapRenderDistance 8e3
#define cloudShadowmapResolution 512