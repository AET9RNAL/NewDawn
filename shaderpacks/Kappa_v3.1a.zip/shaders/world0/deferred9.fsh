#version 400 compatibility

/*
====================================================================================================

    Copyright (C) 2020 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

/*DRAWBUFFERS:01235*/
layout(location = 0) out vec4 scene;
layout(location = 1) out uvec4 sceneData;
layout(location = 2) out vec4 data2;
layout(location = 3) out vec4 data3;
layout(location = 4) out vec4 data5;

#include "/lib/head.glsl"
#include "/lib/util/encoders.glsl"
#include "/lib/util/colorspace.glsl"

const int shadowMapResolution   = 3072;     //[512 1024 1536 2048 2560 3072 3584 4096 6144 8192 16384]
const float shadowDistance      = 128.0;

const bool shadowHardwareFiltering = false;

in vec2 coord;

flat in mat4x3 lightColor;

uniform sampler2D colortex0;
uniform usampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex5;
uniform sampler2D colortex6;

uniform sampler2D noisetex;

uniform sampler2D depthtex0;
uniform sampler2D depthtex2;

uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;

uniform int frameCounter;
uniform int isEyeInWater;

uniform float aspectRatio;
uniform float far, near;
uniform float lightFlip;
uniform float sunAngle;
uniform float viewHeight, viewWidth;

uniform vec2 skyCaptureResolution;
uniform vec2 taaOffset;
uniform vec2 viewSize, pixelSize;

uniform vec3 lightvec, lightvecView;
uniform vec3 upvec, upvecView;

uniform mat4 gbufferModelView, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferProjectionInverse;
uniform mat4 shadowModelView, shadowModelViewInverse;
uniform mat4 shadowProjection, shadowProjectionInverse;


/* ------ includes ------ */
#include "/lib/util/transforms.glsl"

#define FUTIL_LINDEPTH
#define FUTIL_MAT16
#define FUTIL_LIGHTMAP
#include "/lib/fUtil.glsl"

#define ATROUS_POSTRT
#include "/lib/util/kernel.glsl"
#include "/lib/light/indirect/atrousUpscale.glsl"

#include "/lib/light/diffuse.glsl"

#include "/lib/light/warp.glsl"

#include "/lib/frag/bluenoise.glsl"
#include "/lib/frag/gradnoise.glsl"

#define SOLIDPASS

#include "/lib/light/shadow.glsl"

#include "/lib/atmos/phase.glsl"

#include "/lib/light/subsurface.glsl"

#include "/lib/light/contactShadow.glsl"

#include "/lib/light/brdf.glsl"

#include "/lib/frag/labPBR.glsl"


/* ------ metal albedo encoding ------ */

float bayer2e(vec2 a){
    a = floor(a);
    return fract( dot(a, vec2(.5, a.y * .75)) );
}
#define bayer4e(a)   (bayer2e( .5*(a))*.25+bayer2e(a))

#define m vec3(31,63,31)
float encode3x8(vec3 a){
    float dither = bayer4e(gl_FragCoord.xy);
    a += (dither-.5) / m;
    a = saturate(a);
    ivec3 b = ivec3(a*m);
    return float( b.r|(b.g<<5)|(b.b<<11) ) / 65535.;
}
#undef m


uint packAuxData(in vec3 albedo, in float parallaxShadow, in float rain, in float wetness) {
    const vec3 albedoBits  = vec3(31.0, 63.0, 31.0);

    float dither = bayer4e(gl_FragCoord.xy);
        albedo  = saturate(albedo + (dither - 0.5) / albedoBits) * albedoBits;

    uint bf     = uint(albedo.x);
        bf      = bitfieldInsert(bf, uint(albedo.y), 5, 6);
        bf      = bitfieldInsert(bf, uint(albedo.z), 11, 5);
        bf      = bitfieldInsert(bf, uint(parallaxShadow * 63.0), 16, 4);
        bf      = bitfieldInsert(bf, uint(rain * 63.0), 20, 4);
        bf      = bitfieldInsert(bf, uint(wetness * 255.0), 24, 8);

    return bf;
}

vec3 fauxPorosity(vec3 albedo, float wetness, float porosity) {
    //wetness = 1.0;
    vec3 wetAlbedo      = colorSaturation(mix(albedo * sqrt(albedo), sqr(albedo), getLuma(albedo)), 0.85);
        //wetAlbedo       = albedo;
    float frcBounced    = 0.7 * porosity;
        wetAlbedo      = (1.0 - frcBounced) * wetAlbedo / (1.0 - frcBounced * wetAlbedo);

    return mix(albedo, wetAlbedo, wetness);
}

float readCloudShadowmap(sampler2D shadowmap, vec3 position) {
    position    = mat3(shadowModelView) * position;
    position   /= cloudShadowmapRenderDistance;
    position.xy = position.xy * 0.5 + 0.5;

    position.xy /= max(viewSize / cloudShadowmapResolution, 1.0);

    return texture(shadowmap, position.xy).a;
}

void main() {
    vec4 sceneColor     = stex(colortex0);
    float sceneDepth    = stex(depthtex0).x;

    uvec4 tex1          = stex(colortex1);
    vec4 unpackW        = unpack4x8(tex1.w);
    float parallaxShadow = unpackW.x;
    float materialAO    = unpackW.y;
    float wetness       = unpackW.z;
        //tex1.w          = pack2x16(vec2(encode3x8(sqrt(saturate(sceneColor.rgb))), parallaxShadow));
        tex1.w          = packAuxData(sqrt(saturate(sceneColor.rgb)), parallaxShadow, unpackW.w, wetness);

    vec3 albedo         = sceneColor.rgb;

    #if DEBUG_VIEW!=4
    if (landMask(sceneDepth)) {
            vec2 d1     = unpack2x16(tex1.y);
        vec2 sceneLmap  = decode2x8(d1.x);

        vec3 sceneNormal = decodeNormal(unpack2x16(tex1.x));
        vec3 viewNormal = mat3(gbufferModelView) * sceneNormal;

        int matID       = decodeMatID16(d1.y);

        vec4 specularData = unpack4x8(tex1.z);

        materialLAB matLAB = decodeSpecularTexture(specularData);

        #ifndef resourcepackReflectionsEnabled
            matLAB.porosity = 0.6;
        #endif

        sceneColor.rgb  = fauxPorosity(sceneColor.rgb, wetness, matLAB.porosity);

        vec3 viewPos    = screenToViewSpace(vec3(coord, sceneDepth));
        vec3 viewDir    = normalize(viewPos);
        vec3 scenePos   = viewToSceneSpace(viewPos);

        /*
        float rtao      = 1.0;

        #ifndef rtaoEnabled
            rtao    = 1.0;
        #endif

        float ao        = sqr(sceneColor.a)*0.66+0.34;
        */
        
        /* ------ lighting calculation ------ */
        //~6 fps
        
        vec2 lmap       = sceneLmap;
        lmap.y          = cube(lmap.y);

        #if diffuseModel == 0
        float diff      = diffuseHammon(viewNormal, -viewDir, lightvecView, matLAB.roughness);
        #else
        float diff      = diffuseLambert(sceneNormal, lightvec);
        #endif

        #ifndef subsurfaceScatteringEnabled
            if (matID == 2) diff = diff*0.3+0.7 / pi;
            if (matID == 4) diff = sqrt(diff);
        #endif

        shadowData shadow = shadowData(1.0, vec3(1.0), vec3(0.0));

        #ifdef subsurfaceScatteringEnabled
            bool isSSS = matID == 2 || matID == 4;
            if (isSSS || matLAB.opacity > 0.002) shadow = getShadowSubsurface(diff>0.0, scenePos, normalize(viewPos), sceneColor.rgb, max(float(isSSS), matLAB.opacity));
            else shadow = getShadowRegular(diff>0.0, scenePos);    //~3fps, almost for free
        #else
            shadow = getShadowRegular(diff>0.0, scenePos);    //~3fps, almost for free
        #endif

        #ifdef shadowVPSEnabled
            float diffLit       = diff * saturate(shadow.shadow * parallaxShadow);
        #else
            float diffLit       = min(diff, shadow.shadow * parallaxShadow);
        #endif

        #ifdef contactShadowsEnabled
            if (diffLit > 0.0) diffLit *= getContactShadow(depthtex0, viewPos, ditherBluenoise(), sceneDepth, dot(viewNormal, viewDir), lightvecView);
            //if (diffLit > 0.0) diffLit *= getRTShadow(viewPos, ditherBluenoise());
        #endif

        float cloudShadows  = readCloudShadowmap(colortex0, scenePos);

        vec3 directCol      = (sunAngle<0.5 ? lightColor[0] : lightColor[2]) * lightFlip * cloudShadows;
        vec3 directLight    = diffLit * shadow.color * directCol;
        vec3 specDirectLight = directLight;

        materialProperties material     = materialProperties(1.0, 0.04, false, false, mat2x3(1.0));
                material    = labToGeneric(matLAB);

        #ifdef subsurfaceScatteringEnabled
            directLight    += shadow.subsurfaceScatter * directCol;
        #endif

        #ifdef lightleakWorkaroundToggle
            directLight    *= sstep(sceneLmap.y, 0.1, 0.2);
        #endif

        vec3 indirectLight = atrous3x3(colortex3, depthtex0, colortex6, coord, 1).rgb;

        vec3 result     = directLight + indirectLight * materialAO;

        vec2 emissionParam = decode2x8(stex(colortex2).z);

        #ifndef labEmissionEnabled
            emissionParam.y = 0.0;
        #endif

        #ifdef emitterBoostEnabled
            float emissionAlpha = max2(emissionParam);

            if (emissionAlpha > 0.001) {
                bool hand       = stex(depthtex0).x < stex(depthtex2).x;
                float albedoLum     = getLuma(albedo.rgb);

                vec3 emitterCol     = mix(lightColor[3], vec3(v3avg(lightColor[3])), emitterRecoloring);
                    emitterCol    *= saturate(mix(cube(albedoLum) * normalize(albedo.rgb), albedo.rgb, albedoLum));

                result += (emitterCol * emissionParam.x + albedo * emissionParam.y) * (pi * (1.0 - float(hand)));
            }
        #else
            if (emissionParam.y > 1e-2) {
                bool hand       = stex(depthtex0).x < stex(depthtex2).x;
                result += (albedo * emissionParam.y) * (pi * (1.0 - float(hand)));
            }
        #endif

        sceneColor.rgb *= result;

        #if DEBUG_VIEW == 1
            sceneColor.rgb = 0.5 * result;
        #endif

        #ifdef specularBRDFEnabled
        if (diffLit > 0.0) {
            vec3 brdf   = BRDF(-viewDir, lightvecView, viewNormal, material, albedo) * specDirectLight;

            #ifdef lightleakWorkaroundToggle
                brdf   *= sstep(sceneLmap.y, 0.1, 0.2);
            #endif

            //vec3 fresnel = BRDFfresnel(-viewDir, viewNormal, material);
            sceneColor.rgb = sceneColor.rgb + brdf;
            //sceneColor.rgb *= fresnel;
        }
        #endif

        #ifdef deffNAN
        if (isnan3(sceneColor.rgb) || isinf3(sceneColor.rgb)) sceneColor.g = 100.0;
        #endif

        //sceneColor.rgb = vec3(indirectOcclusion) * directCol * 0.5;

        //sceneColor.rgb    = shadow.subsurfaceScatter;
        //sceneColor.rgb  = vec3(getContactShadow(depthtex0, viewPos, ditherBluenoise(), sceneDepth, dot(viewNormal, viewDir)));

        #if DEBUG_VIEW==2
            sceneColor.rgb    = vec3(indirectOcclusion.x) * (sunAngle<0.5 ? lightColor[0] : lightColor[2]);

            #ifdef DEBUG_WITH_ALBEDO
                sceneColor.rgb *= albedo;
            #endif
        #endif

        #if DEBUG_VIEW==3
            sceneColor.rgb    = indirectLight;

            #ifdef DEBUG_WITH_ALBEDO
                sceneColor.rgb *= albedo;
            #endif
        #endif

        //sceneColor.rgb  = vec3(unpackW.w * tau);
    }
    #endif

    scene       = makeDrawbuffer(sceneColor);
    sceneData   = tex1;
    data2       = vec4(0.0);
    data3       = vec4(0.0);
    data5       = clamp16F(vec4(stex(colortex5).rgb, stex(colortex0).a));
}