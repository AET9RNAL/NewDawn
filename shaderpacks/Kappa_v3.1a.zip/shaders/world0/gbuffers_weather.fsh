#version 400 compatibility

/*
====================================================================================================

    Copyright (C) 2020 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

/*DRAWBUFFERS:2*/
layout(location = 0) out vec4 aux2;

#include "/lib/head.glsl"
#include "/lib/util/encoders.glsl"

in vec2 coord;

in vec4 tint;

uniform sampler2D gcolor;

void main() {

    #if MC_VERSION >= 11500
        discard;
    #endif

        vec4 sceneColor   = texture(gcolor, coord * vec2(3.0, 1.4));
            sceneColor.a *= tint.a;
        if (sceneColor.a<0.3) discard;

    const int matID = 3;

    aux2 = vec4(encodeMatID16(matID), 0.0, 0.0, 1.0);
}