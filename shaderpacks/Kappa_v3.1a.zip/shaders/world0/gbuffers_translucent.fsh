/*
====================================================================================================

    Copyright (C) 2020 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

/*DRAWBUFFERS:326*/
layout(location = 0) out vec4 sceneAlbedo;
layout(location = 1) out vec4 sceneData0;
layout(location = 2) out vec4 sceneData1;

#include "/lib/head.glsl"
#include "/lib/util/colorspace.glsl"
#include "/lib/util/encoders.glsl"

const int shadowMapResolution   = 3072;     //[512 1024 1536 2048 4560 3072 3584 4096 6144 8192 16384]

const bool shadowHardwareFiltering = false;

in mat2x2 coord;

in float warp;

in vec3 shadowmapPos;
in vec3 worldPos;

in vec4 tint;

flat in int matID;

flat in vec3 normal;

flat in mat4x3 lightColor;

#ifdef gTERRAIN
    in float viewDist;
    flat in mat3 tbn;
    in vec3 tangentViewDir;
#endif

uniform sampler2D gcolor;
uniform sampler2D specular;
uniform sampler2D normals;

uniform sampler2D noisetex;

uniform int frameCounter;

uniform float frameTimeCounter;
uniform float lightFlip;
uniform float sunAngle;

uniform vec3 lightvec, lightvecView;

uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;

/* ------ includes ------ */
#define FUTIL_LIGHTMAP
#define FUTIL_ROT2
#include "/lib/fUtil.glsl"

#include "/lib/frag/bluenoise.glsl"
#include "/lib/frag/gradnoise.glsl"

#include "/lib/light/diffuse.glsl"
#include "/lib/light/shadow.glsl"


float bayer2e(vec2 a){
    a = floor(a);
    return fract( dot(a, vec2(.5, a.y * .75)) );
}
#define bayer4e(a)   (bayer2e( .5*(a))*.25+bayer2e(a))

#define m vec3(31,63,31)
float encode3x8(vec3 a){
    float dither = bayer4e(gl_FragCoord.xy);
    a += (dither-.5) / m;
    a = saturate(a);
    ivec3 b = ivec3(a*m);
    return float( b.r|(b.g<<5)|(b.b<<11) ) / 65535.;
}
#undef m

#ifdef gTERRAIN

vec3 decodeNormalTexture(vec3 ntex) {
    if(all(lessThan(ntex, vec3(0.003)))) return normal;

    vec3 nrm    = ntex * 2.0 - (254.0 * rcp(255.0));

    #if normalmapFormat==0
        nrm.z  = sqrt(saturate(1.0 - dot(nrm.xy, nrm.xy)));
    #elif normalmapFormat==1
        nrm    = normalize(nrm);
    #endif

    return normalize(nrm * tbn);
}

#include "/lib/util/bicubic.glsl"

#include "/lib/atmos/waterWaves.glsl"

#define waterParallaxDepth 2.0

vec3 waterParallax(vec3 pos, vec3 dir) {    //based on spectrum by zombye
    const uint steps    = 10;

    vec3 interval   = inversesqrt(float(steps)) * dir / -dir.y;
    float height    = waterWaves(pos) * waterParallaxDepth;
    float stepSize  = height;
        pos.xz     += stepSize * interval.xz;

    float offset    = stepSize * interval.y;
        height      = waterWaves(pos) * waterParallaxDepth;

    for (uint i = 1; i < steps - 1 && height < offset; ++i) {
        stepSize    = offset - height;
        pos.xz     += stepSize * interval.xz;

        offset     += stepSize * interval.y;
        height      = waterWaves(pos) * waterParallaxDepth;
    }

    if (height < offset) {
        stepSize    = offset - height;
        pos.xz     += stepSize * interval.xz;
    }

    return pos;
}

vec3 waterNormal() {
    vec3 pos    = waterParallax(worldPos, tangentViewDir.xzy);

    //float dstep   = 0.015 + (1.0 - exp(-viewDist * rcp(32.0))) * 0.045;

    float dstep   = 0.015 + clamp(viewDist * rcp(32.0), 0.0, 2.0) * 0.045;

    vec2 delta;
        delta.x     = waterWaves(pos + vec3( dstep, 0.0, -dstep));
        delta.y     = waterWaves(pos + vec3(-dstep, 0.0,  dstep));
        delta      -= waterWaves(pos + vec3(-dstep, 0.0, -dstep));

    return normalize(vec3(-delta.x, 2.0 * dstep, -delta.y));
}
vec3 waterNormal(out vec3 pos) {
        pos     = waterParallax(worldPos, tangentViewDir.xzy);

    float dstep   = 0.015 + clamp(viewDist * rcp(32.0), 0.0, 2.0) * 0.045;

    vec2 delta;
        delta.x     = waterWaves(pos + vec3( dstep, 0.0, -dstep));
        delta.y     = waterWaves(pos + vec3(-dstep, 0.0,  dstep));
        delta      -= waterWaves(pos + vec3(-dstep, 0.0, -dstep));

    return normalize(vec3(-delta.x, 2.0 * dstep, -delta.y));
}

#include "/lib/frag/noise.glsl"

vec3 getIceAlbedo(vec3 pos) {
    pos    *= 1.0;
    float baseLayer     = value3D(pos * 0.5);
        baseLayer      += value3D(pos * 2.0 + baseLayer * 0.25) * 0.5;
        baseLayer      += value3D(pos * 5.0 + baseLayer * 0.5) * 0.25;
        baseLayer      += sqr(value3D(pos * 10.0 + baseLayer * 0.75)) * 0.125;

        baseLayer       = cubeSmooth(saturate(baseLayer / 1.875));

    vec3 albedo     = mix(vec3(0.022, 0.035, 0.07), vec3(0.029, 0.045, 0.08) * 3.0, baseLayer);

    return albedo;
}

#endif

uniform vec2 viewSize;
uniform vec3 cameraPosition;
uniform mat4 shadowModelView;
uniform sampler2D gaux2;

float readCloudShadowmap(sampler2D shadowmap, vec3 position) {
    position    = mat3(shadowModelView) * position;
    position   /= cloudShadowmapRenderDistance;
    position.xy = position.xy * 0.5 + 0.5;

    position.xy /= max(viewSize / cloudShadowmapResolution, 1.0);

    return texture(shadowmap, position.xy).a;
}

void main() {
    vec4 sceneColor   = texture(gcolor, coord[0]);
    if (sceneColor.a<0.02) discard;
        sceneColor.rgb *= tint.rgb;

    vec3 sceneNormal = normal;

    sceneColor.rgb  = toLinear(sceneColor.rgb);
    sceneColor.rgb  = linearToAP1Albedo(sceneColor.rgb);

    vec3 hue    = normalize(sceneColor.rgb);

    vec4 specularData = texture(specular, coord[0]);

    #ifdef gTERRAIN
        if (matID == 102) {
            //sceneColor.a *= 0.7;
            sceneColor = vec4(0.01, 0.03, 0.1, 0.11);
            hue      = vec3(1.0);
            sceneNormal = waterNormal();
        }
        #ifdef customIceEnabled
        else if (matID == 103) {
            vec3 parallaxPos = worldPos;
            sceneNormal = waterNormal(parallaxPos);
            sceneColor = vec4(getIceAlbedo(parallaxPos), 0.92);
            hue      = normalize(sceneColor.rgb);
            specularData.xy = vec2(0.008, 0.06);
        }
        #endif 
        else {
            sceneNormal = decodeNormalTexture(texture(normals, coord[0]).rgb);
        }
    #endif

    vec2 lmap       = coord[1];
    float ao        = tint.a;

    lmap.y          = cube(lmap.y);

    #ifdef gNODIFF
        float diff  = 1.0;
    #else
        float diff      = diffuseLambert(normal, lightvec);
    #endif

    shadowData shadow   = getShadowRegular(diff>0.0);

    float diffLit       = min(diff, shadow.shadow);

    #ifdef cloudShadowsEnabled
    float cloudShadows  = readCloudShadowmap(gaux2, worldPos - cameraPosition);
    #else
    const float cloudShadows = 1.0;
    #endif

    vec3 directCol      = (sunAngle<0.5 ? lightColor[0] : lightColor[2]) * lightFlip * cloudShadows;
    vec3 directLight    = diffLit * shadow.color * directCol;

    #ifdef lightleakWorkaroundToggle
        directLight    *= sstep(coord[1].y, 0.1, 0.2);
    #endif

    vec3 indirectLight  = sqr(lmap.y)*lightColor[1];
        indirectLight  += lmap.y * directCol * 0.06 * (cloudShadows * 0.5 + 0.5);
        indirectLight  += vec3(0.5, 0.7, 1.0) * (0.01 * minLightLuma);
        indirectLight  *= ao;

    vec3 result     = directLight + indirectLight;
        result     += getBlocklightMap(lightColor[3], lmap.x)*ao;

    sceneColor.rgb *= result;

    sceneAlbedo     = makeDrawbuffer(sceneColor.rgb, saturate(sceneColor.a));
    sceneData0      = vec4(encodeNormal(sceneNormal), encode2x8(vec2(coord[1].y, encodeMatID8(matID))), 1.0);
    sceneData1      = vec4(encode3x8(hue), encode2x8(specularData.xy), 1.0, 1.0);
    /*
    sceneData.x     = pack2x16(encodeNormal(sceneNormal));
    sceneData.y     = pack2x16(vec2(encode2x8(coord[1]), encodeMatID16(matID)));
    sceneData.z     = pack4x8(specularData);
    sceneData.w     = pack2x16(vec2(encode3x8(hue), 0.0));*/
}